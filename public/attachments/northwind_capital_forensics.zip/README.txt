NORTHWIND CAPITAL — DIGITAL FORENSICS EXERCISE

A finance analyst resigned on a Friday. On Monday the CFO found the Q3 ledger had leaked. You have a disk image of his laptop and a network capture from the office gateway. He was careful. Nothing in the logs. Find what he took and how he sent it.

Evidence provided
- gateway.pcap — office gateway packet capture
- analyst-laptop.img — laptop disk evidence image
- evidence_bundle.zip — recovered office-document package

Submit the final flag in the exact format KRYPTEIA{...}. Flags found in individual artifacts may be decoys. Correlate evidence across all stages before submitting.

This is a fictional, closed-lab educational exercise. All names, domains, and records are invented. Work only on copies of the supplied evidence.
